// import { Router } from "express";

// import * as authController from "../controllers/adminControllers/adminAuth.controller";
// // import * as categoryController from "../controllers/adminControllers/category.controller";

// import { authenticateAdmin } from "../middlewares/auth.middleware";
// import { authorizeAdmin } from "../middlewares/authorization.middleware";
// import { adminLoginRateLimiter } from "../middlewares/rateLimit.middleware";


// import * as categoryController
//   from "../controllers/adminControllers/category.controller";

// import { validate } from "../middlewares/validation.middleware";



// const router = Router();

// // ==================== ADMIN AUTH ====================

// router.post(
//   "/auth/login",
//   adminLoginRateLimiter,
//   authController.adminLogin,
// );

// // ==================== PROTECTED ADMIN ROUTES ====================

// // router.use(authenticateAdmin);
// // router.use(authorizeAdmin);

// // ==================== ADMIN PROFILE ====================

// // router.get(
// //   "/auth/me",
// //   authController.getProfile,
// // );

// // ==================== CATEGORY ====================

// router.post( "/categories", validate(createCategorySchema), categoryController.createCategory,);



// // router.get(
// //   "/categories",
// //   categoryController.listCategories,
// // );

// // router.get(
// //   "/categories/:id",
// //   categoryController.getCategory,
// // );

// // router.patch(
// //   "/categories/:id",
// //   categoryController.updateCategory,
// // );

// // router.delete(
// //   "/categories/:id",
// //   categoryController.deleteCategory,
// // );

// export default router;








import { Router } from "express";

import { adminLogin } from "../controllers/adminControllers/adminAuth.controller";
import { adminLoginRateLimiter } from "../middlewares/rateLimit.middleware";
import { validate } from "../middlewares/validation.middleware";
import { adminLoginSchema } from "../validations/adminAuth.validation";

import { authenticateAdmin, AuthenticatedRequest} from "../middlewares/auth.middleware";
import { authorizeAdmin } from "../middlewares/authorization.middleware";


 import * as categoryController from "../controllers/adminControllers/category.controller";
 import {createCategorySchema,} from "../validations/category.validation";
import { categoryImageUpload } from "../middlewares/upload.middleware";

import { Response } from "express";

const router = Router();

/*
|--------------------------------------------------------------------------
| Public admin routes
|--------------------------------------------------------------------------
*/

router.post(
  "/auth/login",
  adminLoginRateLimiter,
  validate(adminLoginSchema),
  adminLogin,
);

/*
|--------------------------------------------------------------------------
| Protected admin routes
|--------------------------------------------------------------------------
*/

router.use(authenticateAdmin);
router.use(authorizeAdmin);

router.post(
  "/auth/me",
  (req: AuthenticatedRequest, res: Response) => {
    res.status(200).json({
      success: true,
      message: "Authenticated admin",
      data: req.admin,
    });
  },
);


// Category
router.post(
  "/categories",
  validate(createCategorySchema),
 categoryController.createCategoryController,
);



router.post(
  "/categories/detail",
  authenticateAdmin,
  categoryController.getCategory,
);


router.post(
  "/categories/update",
  authorizeAdmin,
  categoryController.updateCategory,
);


router.post(
  "/categories/delete",
  authorizeAdmin,
  categoryController.deleteCategory,
);



router.post(
  "/categories/images/upload",
  authorizeAdmin,
  categoryImageUpload.array("images", 10),
  categoryController.uploadCategoryImages,
);

export default router;
