import { Request, Response } from "express";

import { loginAdmin } from "../../services/adminAuth.service";
import { HttpStatus } from "../../constants/http.constant";
import { MessageConstant } from "../../constants/message.constant";

export const adminLogin = async (
  req: Request,
  res: Response,
): Promise<void> => {
  try {
    const result = await loginAdmin({
      email: req.body.email,
      password: req.body.password,
    });

    res.status(HttpStatus.OK).json({
      success: true,
      message: MessageConstant.AUTH.LOGIN_SUCCESS,
      data: result,
    });
  } catch (error) {
    const message =
      error instanceof Error
        ? error.message
        : MessageConstant.ERROR.INTERNAL_SERVER;

    res.status(HttpStatus.UNAUTHORIZED).json({
      success: false,
      message,
    });
  }
};