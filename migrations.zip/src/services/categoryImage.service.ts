import Category from "../models/Category";
import CategoryImage from "../models/CategoryImage";
import { CategoryConstant } from "../constants/category.constant";

interface UploadCategoryImagesData {
  categoryId: number;
  files: Express.Multer.File[];
}

export const uploadCategoryImages = async ({
  categoryId,
  files,
}: UploadCategoryImagesData) => {
  const category = await Category.findByPk(categoryId);

  if (!category) {
    throw new Error("Category not found.");
  }

  if (!files || files.length === 0) {
    throw new Error("At least one image is required.");
  }

  const existingImageCount = await CategoryImage.count({
    where: {
      categoryId,
    },
  });

  const totalImageCount = existingImageCount + files.length;

  if (totalImageCount > CategoryConstant.MAX_IMAGES) {
    throw new Error(
      `A category can have maximum ${CategoryConstant.MAX_IMAGES} images.`,
    );
  }

  const imageRecords = files.map((file) => ({
    categoryId,
    image: file.path.replace(/\\/g, "/"),
  }));

  const images = await CategoryImage.bulkCreate(imageRecords);

  return images;
};