import bcrypt from "bcrypt";

import { Admin } from "../models";
import { generateAdminToken } from "../utils/jwt";
import { MessageConstant } from "../constants/message.constant";

interface AdminLoginData {
  email: string;
  password: string;
}

export const loginAdmin = async ({
  email,
  password,
}: AdminLoginData) => {
  const admin = await Admin.findOne({
    where: {
      email,
    },
  });

  if (!admin) {
    throw new Error(
      MessageConstant.AUTH.INVALID_CREDENTIALS,
    );
  }

  const passwordMatched = await bcrypt.compare(
    password,
    admin.password,
  );

  if (!passwordMatched) {
    throw new Error(
      MessageConstant.AUTH.INVALID_CREDENTIALS,
    );
  }

  if (!admin.isActive) {
    throw new Error(
      MessageConstant.AUTH.ADMIN_INACTIVE,
    );
  }

  const token = generateAdminToken({
    id: admin.id,
    email: admin.email,
    role: "admin",
  });

  return {
    token,
    admin: {
      id: admin.id,
      name: admin.name,
      email: admin.email,
      role: "admin",
    },
  };
};